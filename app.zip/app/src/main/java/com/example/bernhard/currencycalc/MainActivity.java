package com.example.bernhard.currencycalc;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MainActivity extends ActionBarActivity implements View.OnClickListener {
    private Button btn_send;
    private EditText amount;
    private Spinner spinner;
    private Context context;
    private String url1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_send = (Button) findViewById(R.id.send);
        amount = (EditText) findViewById(R.id.editText);
        context = getApplicationContext();
        spinner = (Spinner) findViewById(R.id.spinner);
        btn_send.setOnClickListener(this);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v == btn_send) {
            String curr = spinner.getItemAtPosition(spinner.getSelectedItemPosition()).toString();
            //if (amount.getText() == null) amount.setText("1");

            int am = Integer.parseInt(amount.getText().toString());
            try {
                calculateCurr(curr, am);
            } catch (IOException e) {
                e.printStackTrace();

            }


        }
    }

    private void calculateCurr(String curr, int am) throws IOException {
        url1 = "http://api.fixer.io/latest";
        System.out.println(url1);
        String data = getJSON(url1, 10000);
        System.out.println(data);

    }



    public String getJSON(String url1, int timeout) {
        try {
            System.out.println("getJSON");
            URL url = new URL(url1);
            System.out.println("this?");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-length", "0");
            connection.setUseCaches(false);
            connection.setAllowUserInteraction(false);
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(timeout);
            connection.connect();
            System.out.println("connected");
            int status = connection.getResponseCode();
            System.out.println("STATUS: " + status);
            switch (status) {
                case 200:
                case 201:

                    BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    System.out.println("buffered");
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line+"\n");
                    }
                    br.close();
                    return sb.toString();
            }

        } catch (MalformedURLException ex) {
            System.out.print(ex);
        } catch (IOException ex) {
            System.out.print(ex);
        }
        return null;
    }

}
